# Wk1 HTML-CSS Homework: Work Portfolio

## Your Task

This week, you'll build a portfolio page, which you can add to as the course progresses. 

A portfolio of work can showcase your skills and talents to employers looking to fill a part-time or full-time position. An effective portfolio highlights your strongest work as well as the thought processes behind it. Having several deployed projects is a minimum requirement to receive an initial interview at many companies. 

With these points in mind, in this homework you’ll be applying the core skills you've recently learned: flexbox, media queries, and CSS variables. 

**Note:** If you don't have enough web applications to showcase at this point, use placeholder images and names. You can change them to real applications as you create them later in the course.

Let’s take a look at what a user story written from the perspective of a hiring manager might look like. We follow the AS AN / I WANT / SO THAT format in our user story and GIVEN-WHEN-THEN (GWT) format in out accpetance criteria. 


## User Story

```
AS AN employer
I WANT to view a potential employee's deployed portfolio of work samples
SO THAT I can review samples of their work and assess whether they're a good candidate for an open position
```


## Acceptance Criteria

Here are the critical requirements necessary to develop a portfolio that satisfies a typical hiring manager’s needs:

```
GIVEN I need to sample a potential employee's previous work
WHEN I load their portfolio
THEN I am presented with the developer's name, a recent photo or avatar, and links to sections about them, their work, and how to contact them
WHEN I click one of the links in the navigation
THEN the UI scrolls to the corresponding section
WHEN I click on the link to the section about their work
THEN the UI scrolls to a section with titled images of the developer's applications
WHEN I am presented with the developer's first application
THEN that application's image should be larger in size than the others
WHEN I click on the images of the applications
THEN I am taken to that deployed application
WHEN I resize the page or view the site on various screens and devices
THEN I am presented with a responsive layout that adapts to my viewport
```


## Mock-Up

The following animation shows the web application's appearance and functionality:

![portfolio demo](./Assets/Wk1-HTML-CSS-HW-Demo.gif)


## Grading Requirements

* Satisfies all of the above acceptance criteria. 

* Application deployed at live URL. 

* Application loads with no errors.

* Application GitHub URL submitted.

* GitHub repository contains application code.

* Application resembles the mock-up functionality provided in the Challenge instructions.

* Repository has a unique name.

* Repository follows best practices for file structure and naming conventions.

* Repository follows best practices for class/id naming conventions, indentation, quality comments, etc.

* Repository contains multiple descriptive commit messages.

* Repository contains quality README with description, screenshot, link to deployed application.

## Submission

You are required to submit BOTH of the following for review:

* The URL of the deployed application.

* The URL of the GitHub repository that contains your code. Give the repository a unique name and include a README file that describes the project.


